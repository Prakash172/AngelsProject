package com.prakash.pr20020897.angelsproject.models;

public class SentMessageModel {
    private String name;
    private String otp;
    private String time;

    public void setName(String name) {
        this.name = name;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public String getOtp() {
        return otp;
    }

    public String getTime() {
        return time;
    }
}
