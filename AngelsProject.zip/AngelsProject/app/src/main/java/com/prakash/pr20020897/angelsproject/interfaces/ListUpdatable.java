package com.prakash.pr20020897.angelsproject.interfaces;

public interface ListUpdatable {
    void update(String name, String otp, String time);
    // Not used.
}
