package com.prakash.pr20020897.angelsproject.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

/**
 * Created by PR20020897 on 1/5/2019.
 */

public class MyDatabase {

    private static final String TAG = "SentMessageDB";

    private final static String PERSON_TABLE = "SentMessage"; // name of table
    private final static String NAME = "name";
    private final static String OTP = "otp";
    private final static String TIME = "time";

    private MyDatabaseHelper dbHelper;
    private Cursor mCursor;
    private SQLiteDatabase database;
    /**
     * @param context
     */
    public MyDatabase(Context context) {
        dbHelper = new MyDatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
    }


    public long createRecords(String name, String otp, String time) {
        ContentValues values = new ContentValues();
        values.put(NAME, name);
        values.put(OTP,otp);
        values.put(TIME,time);
        return database.insert(PERSON_TABLE, null, values);
    }


    public Cursor selectRecords() {
        mCursor = database.rawQuery("SELECT * FROM "+PERSON_TABLE, null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor; // iterate to get each value.
    }

}