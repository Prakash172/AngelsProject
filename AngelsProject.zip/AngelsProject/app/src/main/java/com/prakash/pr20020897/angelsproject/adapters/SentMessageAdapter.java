package com.prakash.pr20020897.angelsproject.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.prakash.pr20020897.angelsproject.R;
import com.prakash.pr20020897.angelsproject.models.SentMessageModel;
import com.prakash.pr20020897.angelsproject.utils.DateUtil;

import java.util.ArrayList;

public class SentMessageAdapter extends BaseAdapter {


    private Context context;
    private ArrayList<SentMessageModel> sentMessages;

    public SentMessageAdapter(Context context, ArrayList<SentMessageModel> sentMessages) {
        this.context = context;
        this.sentMessages = sentMessages;
    }

    @Override
    public int getCount() {
        return sentMessages.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @SuppressLint("ViewHolder")
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = LayoutInflater.from(context).inflate(R.layout.sent_message_item, null);
        TextView name = view.findViewById(R.id.name);
        TextView otp = view.findViewById(R.id.otp_tv);
        TextView time = view.findViewById(R.id.time_tv);

        name.setText(sentMessages.get(i).getName());
        otp.setText(sentMessages.get(i).getOtp());
        time.setText(sentMessages.get(i).getTime());

        return view;
    }
}
