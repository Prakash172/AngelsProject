package com.prakash.pr20020897.angelsproject.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.prakash.pr20020897.angelsproject.R;
import com.prakash.pr20020897.angelsproject.utils.AnimationDefinition;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class DetailsDisplayActivity extends AppCompatActivity {


    @BindView(R.id.message_ibtn)
    ImageButton messageIbtn;
    @BindView(R.id.name_textView)
    TextView nameTextView;
    @BindView(R.id.email_textView)
    TextView emailTextView;
    @BindView(R.id.phone_textView)
    TextView phoneTextView;

    private String number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_display);
        ButterKnife.bind(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Details");
        setSupportActionBar(toolbar);

        // populating data from intent
        Intent personData = getIntent();
        number = personData.getStringExtra("number");
        nameTextView.setText(personData.getStringExtra("name"));
        emailTextView.setText(personData.getStringExtra("email"));
        phoneTextView.setText(String.format("+91%s", number));

        //Animation code
        AnimationDefinition animationDefinition = new AnimationDefinition(this);
        ViewGroup root = findViewById(R.id.details_llo);
        animationDefinition.setTransitionXAnimationOnViewGroup(root);

    }

    @OnClick(R.id.message_ibtn)
    public void onViewClicked() {
        Intent intent = new Intent(getApplicationContext(), SendMessageActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("number", number);
        intent.putExtra("name", nameTextView.getText().toString());
        startActivity(intent);

    }
}
