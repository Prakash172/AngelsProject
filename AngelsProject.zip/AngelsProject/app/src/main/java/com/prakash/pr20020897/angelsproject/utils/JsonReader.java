package com.prakash.pr20020897.angelsproject.utils;

import android.content.Context;

import java.io.IOException;
import java.io.InputStream;

public class JsonReader {


    private Context context;
    public JsonReader(Context context){
        this.context = context;
    }
    public String loadJSONFromAsset(String filename) {
        String json = null;
        try {
            InputStream is = context.getAssets().open(filename); // filename should be with extension
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            json = new String(buffer, "UTF-8");
            is.close();
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }
}
