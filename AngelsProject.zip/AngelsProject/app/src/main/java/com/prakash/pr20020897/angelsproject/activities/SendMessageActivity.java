package com.prakash.pr20020897.angelsproject.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.button.MaterialButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.prakash.pr20020897.angelsproject.R;
import com.prakash.pr20020897.angelsproject.database.MyDatabase;
import com.prakash.pr20020897.angelsproject.utils.AnimationDefinition;
import com.prakash.pr20020897.angelsproject.utils.DateUtil;
import com.prakash.pr20020897.angelsproject.utils.SendMessageTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutionException;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SendMessageActivity extends AppCompatActivity {

    private static final String TAG = "SendMessageActivity";
    private static final long SPALASH_TIME = 3000;

    @BindView(R.id.progress_bar)
    ProgressBar progressBar;
    @BindView(R.id.otp_generation_line_tv)
    TextView otpGenerationLineTv;
    @BindView(R.id.otp_heading)
    TextView otpHeading;
    @BindView(R.id.otp)
    TextView otp;
    @BindView(R.id.send_otp_btn)
    MaterialButton sendOtpBtn;
    @BindView(R.id.failureText)
    TextView failureText;
    @BindView(R.id.errorTextView)
    TextView errorTextView;
    @BindView(R.id.goBackButton)
    MaterialButton goBackButton;

    private MyDatabase database;

    private String number;
    private String nameStr, otpStr, timeStr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_message);
        ButterKnife.bind(this);

        //--setting up toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Send Message");
        setSupportActionBar(toolbar);

        // database initialization
        database = new MyDatabase(this);

        // getting data from intent
        Intent data = getIntent();
        number = data.getStringExtra("number");
        nameStr = data.getStringExtra("name");

        otp.setVisibility(View.GONE);
        otpHeading.setVisibility(View.GONE);
        sendOtpBtn.setVisibility(View.GONE);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Random random = new Random();
                int otpNum = random.nextInt(899999) + 100000;
                otpStr = Integer.toString(otpNum);
                otpGenerationLineTv.setVisibility(View.GONE);
                progressBar.setVisibility(View.GONE);
                otp.setText(String.format(Locale.ENGLISH, "%d", otpNum));
                otp.setVisibility(View.VISIBLE);
                otpHeading.setVisibility(View.VISIBLE);
                sendOtpBtn.setVisibility(View.VISIBLE);
            }
        }, SPALASH_TIME);

    }

    @OnClick(R.id.send_otp_btn)
    public void onViewClicked() {
        timeStr = DateUtil.Time();
        sendOtpBtn.setEnabled(false);
        goBackButton.setVisibility(View.VISIBLE);
        SendMessageTask task = new SendMessageTask();
        try {
            String result = task.execute(otpStr,number).get();
            if (isMessageDelivered(result)) {
                database.createRecords(nameStr, otpStr, timeStr);
                failureText.setText(R.string.success);
                failureText.setTextColor(Color.GREEN);
                Toast.makeText(this, "data inserted", Toast.LENGTH_SHORT).show();
            } else errorTextView.setVisibility(View.VISIBLE);
            failureText.setVisibility(View.VISIBLE);
            Log.i(TAG, "onViewClicked: " + result);
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            Log.i(TAG, "onViewClicked: task failed");
        }

    }

    public void goToHomePage(View view) {
        Intent home = new Intent(this, HomeActivity.class);
        home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(home);
    }

    private boolean isMessageDelivered(String message) {
        try {
            JSONObject jsonObject = new JSONObject(message);
            String status = jsonObject.getString("status");
            if (status.equals("failure")) {
                JSONArray errors = jsonObject.getJSONArray("errors");
                JSONArray warnings = jsonObject.getJSONArray("warnings");
                String errorMessage = errors.getJSONObject(0).getString("message");
                String warningMessage = warnings.getJSONObject(0).getString("message");
                errorTextView.setText(warningMessage+"\n"+errorMessage);
                return false;
            } else return true;
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }
}
