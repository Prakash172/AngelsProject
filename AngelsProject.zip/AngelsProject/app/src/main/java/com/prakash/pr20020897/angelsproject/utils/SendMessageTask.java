package com.prakash.pr20020897.angelsproject.utils;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.prakash.pr20020897.angelsproject.R;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class SendMessageTask extends AsyncTask<String, Void, String> {

    private static final String TAG = "SendMessageTask";
    @Override
    protected String doInBackground(String... strings) {

        try {
            // Construct data
            String apiKey = "apikey=" + "Axk3wzMqN4w-JXWdRCR3gjDjekZZom6iMMRmmVgcVb";
            String message = "&message=" + "Hi, Your OTP is:"+strings[0];
            Log.i(TAG, "number: "+strings[1]);
            String sender = "&sender=" + "TXTLCL";
            String numbers = "&numbers=" +strings[1];

            // Send data
            HttpURLConnection conn = (HttpURLConnection) new URL("https://api.textlocal.in/send/?").openConnection();
            String data = apiKey + numbers + message + sender;
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Length", Integer.toString(data.length()));
            conn.getOutputStream().write(data.getBytes("UTF-8"));
            final BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            final StringBuffer stringBuffer = new StringBuffer();
            String line;
            while ((line = rd.readLine()) != null) {
                stringBuffer.append(line);
            }
            rd.close();
            Log.i(TAG, "doInBackground: "+stringBuffer.toString());
            return stringBuffer.toString();
        } catch (Exception e) {
            Log.i("Error ", "sendSms: " + e);
            return "Error " + e;
        }
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        Log.i(TAG, "onPostExecute: "+s);
    }
}
