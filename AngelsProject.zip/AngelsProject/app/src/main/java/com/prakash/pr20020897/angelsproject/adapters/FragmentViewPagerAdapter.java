package com.prakash.pr20020897.angelsproject.adapters;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.util.Log;

import com.prakash.pr20020897.angelsproject.fragments.SentMessagesHistory;
import com.prakash.pr20020897.angelsproject.fragments.PersonsFragment;

public class FragmentViewPagerAdapter extends FragmentPagerAdapter {
    private static final int PAGE_COUNT = 2;
    private Context context ;

    public FragmentViewPagerAdapter(FragmentManager fm, Context context) {
        super(fm);
        this.context = context;
    }

    @Override
    public Fragment getItem(int i) {
        switch (i){
            case 0:
                Log.i("inside adapter", "getItem: "+0);
                return new PersonsFragment();
                case 1:
                    Log.i("inside adapter", "getItem: "+1);
                    return new SentMessagesHistory();
                default:
                    return null;
        }
    }

    @Override
    public int getCount() {
        return PAGE_COUNT;
    }
}
